-- kug_collection.lua

-- Copyright (c) 2020 Amazon Technologies, Inc.  All rights reserved.
-- PROPRIETARY/CONFIDENTIAL
-- Use is subject to license terms.

-- This file contains code to handle changes to the Kindle User Guide
-- virtual collection (KUGC), including Archive KUG Collection (AKUGC)
-- adn Home KUG Collection (HKUGC). AKUGC/HKUGC is similar concept as
-- ADC/HDC (Archive/Home Dictionary Collection).

require 'cc_db_util'

local modname = ...
local kug_collection = {}
_G[modname] = kug_collection

-- This function sets the isVisibleInHome and virtualCollectionCount columns on the AKUGC item.
-- The isVisibleInHome field is set to true when there is at least one KUG item available (archived or unarchived).
-- The virtualCollectionCount filed is set to the number of KUG items.
function kug_collection.update_akugc_item (db)
    llog.debug4("kug_collection.update_akugc_item", "enter", "", "")

    local count = 0
    local sql = "SELECT COUNT(*) AS count FROM Entries WHERE p_isVisibleInHome = 1 AND p_originType = 10"

    local stmt = assert(cc_db_util.package_for_assert(db:prepare(sql)))
    local row, message, code = stmt:first_row()
    stmt:close()

    if row then
        count = row.count
    else
        if code and code ~= 0 then
            llog.error("kug_collection.update_akugc_item", "error", "%s", "", sql)
            assert(cc_db_util.package_for_assert(nil, message, code))
        end
    end
    llog.debug4("kug_collection.update_akugc_item", "count", "akugc_count=%d", "", count)

    local is_visible = 0
    if count > 0 then
        is_visible = 1
    end

    sql = [[UPDATE Entries SET p_virtualCollectionCount = ]] .. count .. [[, p_isVisibleInHome = ]] .. is_visible .. [[ WHERE p_type = 'Entry:Item:AKUGC']]
    assert(cc_db_util.package_for_assert(db:exec( sql)))

    llog.debug4("kug_collection.update_akugc_item", "exit", "akugc_count=%d:is_visible_in_home=%d", "", count, is_visible)
end

-- This function sets the isVisibleInHome and virtualCollectionCount columns on the HKUGC item.
-- The isVisibleInHome field is set to true when there is at least one KUG item on the device.
-- The virtualCollectionCount field is set to the number of KUG items on the device.
function kug_collection.update_hkugc_item (db)
    llog.debug4("kug_collection.update_hkugc_item", "enter", "", "")

    local count = 0
    local sql = "SELECT COUNT(*) AS count FROM Entries WHERE p_isArchived = 0 AND p_isVisibleInHome = 1 AND p_originType = 10"

    local stmt = assert(cc_db_util.package_for_assert(db:prepare(sql)))
    local row, message, code = stmt:first_row()
    stmt:close()

    if row then
        count = row.count
    else
        if code and code ~= 0 then
            llog.error("kug_collection.update_hkugc_item", "error", "%s", "", sql)
            assert(cc_db_util.package_for_assert(nil, message, code))
        end
    end
    llog.debug4("kug_collection.update_hkugc_item", "count", "hkug_count=%d", "", count)

    local is_visible = 0
    if count > 0 then
        is_visible = 1
    end

    sql = [[UPDATE Entries SET p_virtualCollectionCount = ]] .. count .. [[, p_isVisibleInHome = ]] .. is_visible .. [[ WHERE p_type = 'Entry:Item:HKUGC']]
    assert(cc_db_util.package_for_assert(db:exec(sql)))
    llog.debug4("kug_collection.update_hkugc_item", "exit", "hkug_count=%d:is_visible_in_home=%d", "", count, is_visible)
end

--- This function checks whether give uuid is related to KUG item.
--- This is done by querying KUG item count for give uuid from content catalog.
local function is_kug_related_uuid (db, uuid)
    if uuid == nil then
        llog.info("is_kug_related_uuid", "exit", "uuid is_nil", "")
        return false
    end

    local count = 0
    local sql = [[ SELECT COUNT(*) AS count FROM Entries WHERE p_uuid = "]] .. uuid .. [[" AND p_originType = 10 LIMIT 1 ]]

    local stmt = assert(cc_db_util.package_for_assert(db:prepare(sql)))
    local row, message, code = stmt:first_row()
    stmt:close()

    if row then
        count = row.count
    else
        if code and code ~= 0 then
            llog.error("is_kug_related_uuid", "error", "%s", "", sql)
            assert(cc_db_util.package_for_assert(nil, message, code))
        end
    end

    return count > 0
end

--- This function checks whether give cdeKey is related to KUG item.
--- This is done by querying KUG item count for give cdeKey from content catalog.
local function is_kug_related_cdekey (db, cdeKey)
    if cdeKey == nil then
        llog.info("is_kug_related_cdekey", "exit", "cdeKey is_nil", "")
        return false
    end

    local count = 0
    local sql = [[ SELECT COUNT(*) AS count FROM Entries WHERE p_cdeKey = "]] .. cdeKey .. [[" AND p_originType = 10 LIMIT 1 ]]

    local stmt = assert(cc_db_util.package_for_assert(db:prepare(sql)))
    local row, message, code = stmt:first_row()
    stmt:close()

    if row then
        count = row.count
    else
        if code and code ~= 0 then
            llog.error("is_kug_related_cdekey", "error", "%s", "", sql)
            assert(cc_db_util.package_for_assert(nil, message, code))
        end
    end

    return count > 0
end

--- This function checks whether give args is related to KUG item.
--- This is done by querying uuid or cdeKey for KUG item from content catalog.
function kug_collection.is_kug_related (db, args)
    if args.uuid then
        return is_kug_related_uuid(db, args.uuid)
    else
        local cdeKey = args.cdeKey or (args.entry and args.entry.cdeKey)
        return is_kug_related_cdekey(db, cdeKey)
    end
end