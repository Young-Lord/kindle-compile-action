-- appreg.lua

-- Copyright (c) 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
-- PROPRIETARY/CONFIDENTIAL
-- Use is subject to license terms.

-- This file contains code to handle appreg db, specifically reading config values.
local modname = ...
local appreg = {}
_G[modname] = appreg

require 'llog'
require 'cc_db_util'

-- Create Binder
local make_binder = cc_db_util.make_binder

-- DB pointer
local db

-- Set db (appreg db)
function appreg.set_db(db_)
    db = db_
end

-- Begin Transaction on appreg
function appreg.begin()
    assert(cc_db_util.begin(db))
end

-- ROLLBACK Transaction on appreg
function appreg.rollBack()
    db:exec[[ROLLBACK]]
end

-- Commit Transaction on appreg
function appreg.commit()
    assert(cc_db_util.commit(db))
end

function appreg.find_pfm()
    local stmt = nil
    -- dcd is the default handlerId. dcc is the "override" handlerId. marketplace.obfuscated.id is the name storing PFM value from user account. 
    -- Logic can be seen at https://eink-grok.aka.amazon.com/eink_dev_mainline/xref/repo/platform/lib/dynconfig/libdc.c
    -- Query dcc value first; if dcc is empty, use dcd.
    local sql = "SELECT VALUE FROM PROPERTIES WHERE handlerId in ('dcc', 'dcd') and name = 'marketplace.obfuscated.id' and VALUE is not null order by handlerId LIMIT 1"
    
    llog.debug4("appreg", "find_pfm", "sql=%s", "", tostring(sql))
    local resultRow = cc_db_util.select_first_row(db, sql, nil)
    local resultPfm = nil
    if resultRow then
        resultPfm = resultRow.value
    end
    return resultPfm
end